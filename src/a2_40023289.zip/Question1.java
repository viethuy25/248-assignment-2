//-----------------------------------------------
//Assignment 2
//Written by Huy Nguyen, student ID: 40023289
//For COMP 248 Section W - Winter 2017
//-----------------------------------------------
import java.util.Scanner;
/*import the scanner class */
public class Question1 {

	public static void main(String[] args) {
		Scanner keyIn= new Scanner (System.in);
		/*Receive the number of days from the user */
		System.out.print("Enter a positive number of days n : ");
		int n= keyIn.nextInt();
		int y=1;
		
		/*If the days are less or euqal to 365 days, it is 1 year */
		if (n<=365)
			System.out.println("Number of years : "+ y);
		else
		{
			/*If the number of days are greater than 365, keep subtract it with 365 to find how many years it is. */
			while (n>=365)
			{
				n= n-365;
				y=y+1;
			}
			/*Display the result */
			System.out.println("Number of years : "+ y);
		}
		keyIn.close();

	}

}
