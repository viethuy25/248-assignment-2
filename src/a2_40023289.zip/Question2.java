//-----------------------------------------------
//Assignment 2
//Written by Huy Nguyen, student ID: 40023289
//For COMP 248 Section W - Winter 2017
//-----------------------------------------------
public class Question2 {

	public static void main(String[] args) 
	{
		/*Declare 3 integer variable and 2 constant value */
		int col=1,row=1,mult,head=1;
		final int I_MAX=15,J_MAX=10;
		/*Display the message */
		System.out.print("   |" + " ");
		while (head<=10)
		{
			System.out.print(head + "      ");
			head++;
		}
		System.out.println();
		System.out.println("______________________________________________________________________");
		/*Display 10 rows using the for loop */
		for (row=1;row<=I_MAX;row++)
		{		
			/*Customize the left edge hand side */
			if (row<10)
				System.out.print(row+ "  | ");
			else
				System.out.print(row+ " | ");
			/*Customize the display style of each column */
			for (col=1;col<=J_MAX;col++)
			{
				mult=row * col;
				if (col<=row)
					System.out.print(mult+ "    ");
				if (mult < 10)
					System.out.print("  ");
	            else if (mult < 100)
	            	System.out.print(" ");
			}
			/*Go to the next line when the row is done being customized */
				if ((col<=row)||(col>row))
					System.out.println();
		}
	}

}
